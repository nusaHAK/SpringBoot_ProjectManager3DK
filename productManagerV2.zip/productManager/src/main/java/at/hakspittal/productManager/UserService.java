package at.hakspittal.productManager;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
public class UserService {
	@Autowired
	private UserRepository userRepo;
	
	public List<User> listAll(){
		return userRepo.findAll();
	}
	
	public void save(User user) {
		userRepo.save(user);
	}
	
	public void delete(Long uid) {
		userRepo.deleteById(uid);
	}
	
	public User get(Long uid) {
		return userRepo.findById(uid).get();
	}
}
