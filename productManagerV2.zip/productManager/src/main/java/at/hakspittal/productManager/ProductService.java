package at.hakspittal.productManager;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProductService {

	@Autowired
	private ProductRepository repo;
	
	//Liste mit allen Produkten auslesen
	public List<Product> listAll(){
		return repo.findAll();
	}
	
	//ein neues Produkt in der DB speichern
	public void save(Product product) {
		repo.save(product);
	}
	
	//ein Produkt aus der DB löschen
	public void delete(Long id) {
		repo.deleteById(id);
	}
	
	//ein bestimmtes Produkt laden
	public Product get(Long id) {
		return repo.findById(id).get();
	}
	
}
