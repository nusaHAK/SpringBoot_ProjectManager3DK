package at.hakspittal.productManager;

	import java.util.List;
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Controller;
	import org.springframework.ui.Model;
	import org.springframework.web.bind.annotation.ModelAttribute;
	import org.springframework.web.bind.annotation.RequestMapping;
	import org.springframework.web.bind.annotation.RequestMethod;

	//Beim Anzeigen von HTML-Seiten wird die Annotation @Controller verwendet.
	@Controller
	public class UserController {

		@Autowired
		private UserService userService;
		
		@RequestMapping("/users")
		public String viewHomePage(Model model) {
			List<User> listUser = userService.listAll();
			model.addAttribute("listUser",listUser);
			
			return "userlist";
		}
		
		@RequestMapping("/newUser")
		public String showNewProductForm(Model model) {
			User user = new User();
			model.addAttribute("user",user);
			
			return "new_user";
		}
		
		@RequestMapping(value="/saveUser", method = RequestMethod.POST)
		public String saveProduct(@ModelAttribute("user") User user) {
			userService.save(user);
			return "redirect:/users";  //Wir wollen zurück zur Route /
			                      //dort wird die index.html
			                      //angezeigt.
		}
		
	}
